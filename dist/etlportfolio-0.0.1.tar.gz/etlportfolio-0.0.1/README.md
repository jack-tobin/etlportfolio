# etlportfolio
Expected tail loss portfolio optimisation in Python


